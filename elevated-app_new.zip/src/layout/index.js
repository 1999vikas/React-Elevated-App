import React from 'react'
import Header from "./HeaderContent";
import Footer from './Footer'
import { Outlet } from 'react-router-dom';
const index = () => {
  return (
    <>
    <Header/>
    <div className="custom-container">
        <div className="content">
            <div className="removeLayoutFooter">
      <Outlet/>
    <Footer/>

    </div>
    </div>
</div>
    </>
  )
}

export default index