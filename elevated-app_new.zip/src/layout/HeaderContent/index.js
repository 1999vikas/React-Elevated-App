import React from 'react'

const index = () => {
    return (
        <>
            <header className="nav-block box_shadow">
                <div className="custom-container header-align">
                    <div className="header-right">
                        <div className="right_area">
                            <ul className="navbar-right navbar-block nav-flex-icons ml-auto">
                                <span id="den_safecapacity" style={{display:"none"}}></span>
                                <li className="notification-header nav-item avatar dropdown" id="makenotizero">
                                    <a className="nav-link dropdown-toggle waves-effect waves-light">
                                        <span className="notification-count badge badge-danger ml-2 realt" id="realt">0
                                            <i className="fas fa-plus"></i>
                                        </span>
                                        <i className="far fa-bell"></i>
                                    </a>
                                    <div className="notify-drop-menu drop realtdrop inner-scroll-block2">
                                        <div className="realtdecobee"></div>
                                        <div className="realtdcapacity"></div>
                                        <div className="realtdawaire"></div>
                                    </div>
                                </li>
                                <li className="nav-item profile-img">
                                    <a className="nav-link dropdown-profile ">
                                        <img src="https://staging.elevatedenvironments.tech/storage/avtar/1710338236-5D0A7F5C921F44CBBF95C7FA54774587.jpg" className="rounded-circle z-depth-0 123" alt="Profile" />

                                    </a>
                                </li>
                                <li className="nav-item morning-block custom-morning-block-div">
                                    <h2 id="timegreeting">Welcome</h2>
                                    <h2 className="text-start mb-0">Vikash</h2>
                                </li>
                            </ul>





                        </div>
                    </div>



                    <div className="dashboard-header">
                        <div className="tab-built-envt tab-community">

                            <ul className="header-tabs">


                                <li className="item active">
                                    <a id="mdashboard" className="list" href="https://staging.elevatedenvironments.tech/dashboard/eyJpdiI6ImNKYWUwc3R4emRVQ3BRRWNLbnR6cUE9PSIsInZhbHVlIjoiakd6Ym9pbkJFczR5Zm9QclpnWkpDUT09IiwibWFjIjoiODI0MWNmZmI3YzI2ZWFmNGUyNTAzZDAxMzY2YTQ1Yjk4NDZjZWUyM2Y3MjhlY2RmYzJkNzYwNWFkMjM0MjQ2OCIsInRhZyI6IiJ9">
                                        <button className="tablinks hotelmap">
                                            <img className="whiteimg" src="/fdashboard/images/headNavigation/dashboard_line_icon_gray1.svg" alt="dashboard" />
                                            <img className="darkicon" src="/fdashboard/images/headNavigation/dashboard_fill_icon_gray1.svg" alt="dashboard" />
                                            <h2 className="header-nav-title">Dashboard</h2>
                                        </button>
                                    </a>
                                </li>





                                <li className="item">
                                    <a id="mbuilt_environment" className="list" href="https://staging.elevatedenvironments.tech/built_environment">

                                        <button className="tablinks restaurents">
                                            <img className="whiteimg" src="/fdashboard/images/headNavigation/space_line_icon_gray1.svg" alt="Control Center" />
                                            <img className="darkicon" src="/fdashboard/images/headNavigation/space_fill_icon_gray1.svg" alt="Control Center" />
                                            <h2 className="header-nav-title">Space</h2>
                                        </button>
                                    </a>
                                </li>




                                <li className="item">
                                    <a id="mcommunity" className="list" href="https://staging.elevatedenvironments.tech/community">

                                        <button className="tablinks">
                                            <img className="whiteimg" src="/fdashboard/images/headNavigation/community_line_icon_gray1.svg" alt="Community" />
                                            <img className="darkicon" src="/fdashboard/images/headNavigation/community_fill_icon_gray1.svg" alt="Community" />
                                            <h2 className="header-nav-title">Community</h2>
                                        </button>
                                    </a>
                                    <span id="communityBadgeCount" className="analytic-notify-count displayNoneImportant"></span>
                                </li>



                                <li className="item">
                                    <a id="manalytics" className="list" href="https://staging.elevatedenvironments.tech/analytics">

                                        <button className="tablinks">

                                            <img className="whiteimg" src="/fdashboard/images/headNavigation/insight_line_icon_gray1.svg" alt="Analytics" />
                                            <img className="darkicon" src="/fdashboard/images/headNavigation/insight_fill_icon_gray1.svg" alt="Analytics" />
                                            <h2 className="header-nav-title">Insight</h2>
                                        </button>
                                    </a>

                                </li>

                                <li className="item nav-item profile-img profile-click">
                                    <img className="whiteimg setting-icon" src="/fdashboard/images/MainNav_Setting_Icon_Blue1.svg" alt="dashboard" />

                                    <div className="dropdown-menu dropdown-menu-right dropdown-secondary profile-block">

                                        <img className="whiteimg position setting-icon" src="/fdashboard/images/MainNav_Setting_Icon_Yellow1.svg" alt="dashboard" />
                                        <ul className="navbar-right nav-flex-icons">
                                            <li className="nav-item morning-block">
                                                <h2 id="timegreeting">Welcome</h2>
                                                <h6>Vikash</h6>
                                            </li>
                                        </ul>
                                        <ul className="nav navbar-nav navbar-right custom-align">


                                            <li>
                                                <a className="w-100" href="https://staging.elevatedenvironments.tech/organization">Organizations</a>
                                            </li>
                                            <li>
                                                <a href="https://staging.elevatedenvironments.tech/commission" className="w-100">Commissioning</a>
                                            </li>

                                            <li>
                                                <a href="https://staging.elevatedenvironments.tech/energy-settings" className="w-100">Energy settings</a>
                                            </li>
                                            <li className="profile-dropdown">
                                                <a onclick="event.preventDefault()" className="custome-dropdown-css">User settings</a>
                                                <ul className="sub-menus">

                                                    <li><a href="https://staging.elevatedenvironments.tech/create-organizatoin-department">Create new DepartMent</a></li>
                                                    <li><a href="https://staging.elevatedenvironments.tech/create-organizatoin-member">Create new user</a></li>
                                                    <li><a href="https://staging.elevatedenvironments.tech/organizatoin-member-list/eyJpdiI6ImNKYWUwc3R4emRVQ3BRRWNLbnR6cUE9PSIsInZhbHVlIjoiakd6Ym9pbkJFczR5Zm9QclpnWkpDUT09IiwibWFjIjoiODI0MWNmZmI3YzI2ZWFmNGUyNTAzZDAxMzY2YTQ1Yjk4NDZjZWUyM2Y3MjhlY2RmYzJkNzYwNWFkMjM0MjQ2OCIsInRhZyI6IiJ9">Manage users</a></li>
                                                    <li><a href="https://staging.elevatedenvironments.tech/create-admin">Manage system admin</a></li>
                                                    <li><a href="https://staging.elevatedenvironments.tech/import-organizatoin-member">Import new users</a></li>
                                                </ul>
                                            </li>
                                            <li className="helllo">
                                                <a href="https://staging.elevatedenvironments.tech/user-activity/eyJpdiI6ImNKYWUwc3R4emRVQ3BRRWNLbnR6cUE9PSIsInZhbHVlIjoiakd6Ym9pbkJFczR5Zm9QclpnWkpDUT09IiwibWFjIjoiODI0MWNmZmI3YzI2ZWFmNGUyNTAzZDAxMzY2YTQ1Yjk4NDZjZWUyM2Y3MjhlY2RmYzJkNzYwNWFkMjM0MjQ2OCIsInRhZyI6IiJ9/desk" className="w-100">User Activity</a>
                                            </li>
                                            <li className="helllo">
                                                <a href="https://staging.elevatedenvironments.tech/getFloorActivity" className="w-100">Floor Plan Activity</a>
                                            </li>
                                            <li>
                                                <a href="https://staging.elevatedenvironments.tech/floorplan-list/eyJpdiI6ImNKYWUwc3R4emRVQ3BRRWNLbnR6cUE9PSIsInZhbHVlIjoiakd6Ym9pbkJFczR5Zm9QclpnWkpDUT09IiwibWFjIjoiODI0MWNmZmI3YzI2ZWFmNGUyNTAzZDAxMzY2YTQ1Yjk4NDZjZWUyM2Y3MjhlY2RmYzJkNzYwNWFkMjM0MjQ2OCIsInRhZyI6IiJ9" className="w-100">Floor Plan</a>
                                            </li>


                                            <li className="helllo">
                                                <a href="https://staging.elevatedenvironments.tech/user-logs/eyJpdiI6ImNKYWUwc3R4emRVQ3BRRWNLbnR6cUE9PSIsInZhbHVlIjoiakd6Ym9pbkJFczR5Zm9QclpnWkpDUT09IiwibWFjIjoiODI0MWNmZmI3YzI2ZWFmNGUyNTAzZDAxMzY2YTQ1Yjk4NDZjZWUyM2Y3MjhlY2RmYzJkNzYwNWFkMjM0MjQ2OCIsInRhZyI6IiJ9" className="w-100">User Logs</a>
                                            </li>
                                            <hr />
                                            <li className="w-100">
                                                <a href="https://staging.elevatedenvironments.tech/edit-admin/default/eyJpdiI6InRibkdSQjhLalczU0g4dHFKOTdIaFE9PSIsInZhbHVlIjoiT2dKbVlWL0tkUEhpQ0w5MDZOM0lldz09IiwibWFjIjoiZjI0ZWU3ZWY3ODcyNzNhMzM0ZGIyYzU0YjEwY2ViNmZmY2RjMWFkODg3ZTdhYzAyM2NhYjQ2YzAxNDYwOTFhZSIsInRhZyI6IiJ9" className="w-100">Account settings</a>
                                            </li>
                                            <li className="">
                                                <a href="https://staging.elevatedenvironments.tech/orgnization-notification">Announcements</a>
                                            </li>


                                            <li id="mylogout">
                                                <a href="https://staging.elevatedenvironments.tech/logout" onclick="event.preventDefault();document.getElementById('logout-form').submit();" className="w-100">
                                                    Logout
                                                    <form id="logout-form" action="https://staging.elevatedenvironments.tech/logout" method="POST" style={{display:"none"}}>
                                                        <input type="hidden" name="_token" value="GjgUi7QUjaGkUVcIjbagswGZCPa3RInc6r9OmBDC" />
                                                    </form>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                    <h2 className="header-nav-title">Settings</h2>

                                </li>



                            </ul>
                        </div>



                    </div>



                </div>
            </header>
        </>
    )
}

export default index