import React from 'react'

const index = () => {
  return (
    <footer className="footer-section blue mt-5 text-center">
      <img className="whiteimg mb-3" src="https://staging.elevatedenvironments.tech/fdashboard/images/PoweredByElevatedTM-CreamLogo.svg" alt="footer logo" />
      <div className="footer-copyright text-center">Copyright © EnvironmentsbyLE | All rights reserved 2020 - 2024
      </div>
    </footer>
  )
}

export default index