import React,{ lazy, Suspense }  from 'react'
import { Routes,Route } from 'react-router-dom'
import Layout from '../layout'
import PageLoader from '../pages/PageLoader';

const DashBorad=React.lazy(()=>import("../pages/dashBoard"));

const AppRouter = () => {
  return (
    <Suspense fallback={<PageLoader/>}>
       <Routes>
        <Route path='/' element={<Layout/>}>
          <Route path='/home' element={<DashBorad/>}/>
       </Route>
       </Routes>
    </Suspense>
    
  )
}

export default AppRouter