import React, { Suspense } from "react";
import { Layout as Layouts } from "antd";
import AuthRouter from "./AuthRouter";
import AppRouter from "./AppRouter";
import { BrowserRouter, Route, Routes, useLocation } from "react-router-dom";
import UserPrivateRoutes from "../pages/privateRoutes/UserPrivateRoutes";
import Layout from "../layout";
import Login from "../pages/Login";


const DashBorad = React.lazy(() => import("../pages/dashBoard"));

export default function Router() {
  const token = localStorage.getItem("access-token");
  const isLoggedIn = token ? true : false;

  return (
    <Layouts style={{ minHeight: "100vh", background: "#222222" }}>
        <Suspense fallback={"Loading......"}>
      <Routes>

        <Route element={<Login/>} path={"/login"}/>

        <Route element={<UserPrivateRoutes permission={"create-user"} />}>
          <Route path="/" element={<Layout />}>
          <Route path="/" exact element={<DashBorad />} />
            <Route path="/home" exact element={<DashBorad />} />
            <Route path="/space" exact element={<h2>Space Page....</h2>} />
            <Route path="/community" exact element={<h2>Community....</h2>} />
            <Route path="/in-sight" exact element={<h2>in-sight....</h2>} />
          </Route>
        </Route>
        
      </Routes>
      </Suspense>
    </Layouts>
  );
}
