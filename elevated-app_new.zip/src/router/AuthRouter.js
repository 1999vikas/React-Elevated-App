import React, { Suspense, lazy } from "react";
import { BrowserRouter, Route, Routes, useLocation } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import PublicRoute from "./PublicRoute";
import PageLoader from "../pages/PageLoader";

const Login = lazy(() => import("../pages/Login"));


const AuthRouter = () => {
    return (
        <Suspense fallback={<PageLoader/>}>
            <AnimatePresence initial={false}> 
                    <PublicRoute
                     path="/"
                     component={Login}
                    />

             <PublicRoute
                     path="/login"
                     component={Login}
                    />
            </AnimatePresence>
        </Suspense>
    )
}
export default AuthRouter