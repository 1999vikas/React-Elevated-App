import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom';

const PublicRoute = ({ component: Component, ...rest }) => {

    return (
        <Routes>
            <Route
                {...rest}
                element={<Component />}
            />
        </Routes>
    );
}

export default PublicRoute