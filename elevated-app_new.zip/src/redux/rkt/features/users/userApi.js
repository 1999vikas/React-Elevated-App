import { apiSlice } from "../api/apiSlice";
import { toastHandler } from "../../../../utils/functions";


export const userApi=apiSlice.injectEndpoints({
    endpoints:(builder)=>({
        login:builder.mutation({
            query:(values)=>({
                method:"POST",
                headers:{
                    Accept:"application/json",
                    "Content-Type":"application/json;charset=UTF-8"
                },
                url:`user/login`,
                body:values,
            }),
        async onQueryStarted(arg, { queryFulfilled, dispatch }) {
            try {
                const { data } = await queryFulfilled;
                console.log("queryFulfilled",data);

                localStorage.setItem("access-token", data?.token);
                localStorage.setItem("role", data?.role);
                localStorage.setItem("user", data?.username);
                localStorage.setItem("id", data?.id);
                localStorage.setItem("isLogged", true);

                toastHandler("User logged in successfully","success");
                window.location.href = "/";
                }catch(err){

                }
            }
        })
    })
});


export const {useLoginMutation}=userApi;

