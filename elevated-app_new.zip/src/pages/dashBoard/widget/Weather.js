import React from "react";

const Weather = () => {
  return (
    <>
      <div className="desk__card card__weather">
        <div className="le-temp-block">
          <div className="date-time-header org_date">
            <p id="orgTime">
              Today is Friday, June 28, 2024
              <br /> It's <span id="orgTimeChange">8:55 AM</span> in Richmond
            </p>
          </div>
          <div className="lighting-user-temp">
            <div className="tempra-block tempra-block-location">
              <a
                target="_blank"
                href="http://www.accuweather.com/en/us/richmond-va/23220/current-weather/9607_pc?lang=en-us"
              >
                <div className="current-temp-block">
                  <h2>
                    68<sup>o</sup>F
                  </h2>
                </div>
                <div className="cloud-block">
                  <div className="sunny-cloud">
                    <img
                      typeof="foaf:Image"
                      className="img img-responsive"
                      src="https://developer.accuweather.com/sites/default/files/34-s.png"
                      alt="Weather"
                      title=""
                    />
                  </div>
                  <div className="city-location">
                    <h4>Richmond</h4>
                    <p>Mostly clear</p>
                  </div>
                </div>
              </a>
            </div>
          </div>
          <div className="air-quality-text">
            <div>
              Outdoor Air Quality is{" "}
              <span className="healthy" style={{ color: "#E0DF6A" }}>
                <span
                  className="health-circle"
                  style={{ background: "#E0DF6A" }}
                ></span>
                Moderate
              </span>
            </div>
            <div id="indoorAirQualityId">
              Indoor Air Quality is{" "}
              <span className="healthy" style={{ background: "#58FFBF" }}>
                <span
                  className="health-circle"
                  style={{ backgroundColor: "#58FFBF" }}
                ></span>
                Excellent
              </span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Weather;
