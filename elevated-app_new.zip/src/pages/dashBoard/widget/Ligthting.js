import React from "react";

const Ligthting = () => {
  return (
    <>
      <div className="desk__card card__ligtning__control">
        <div className="lighting-controls-block api_fail api_fail_wrap inner-scroll-block2 light-scroll">
          <div className="desk_lightcont_list">
            <div className="inner-block closeButton">
              <div className="areas-coltrol">
                <div className="confrenceRoomBlock">
                  <div className="lightHeader">
                    <h2>Color Kinetics</h2>
                    <div className="activateBtnBlock">
                      <div className="activateLight ConferenceL off">
                        <span className="currentPresetNameCircle"></span>
                        <span className="currentPresetName"> Off</span>
                      </div>
                    </div>
                  </div>
                  <div className="preset-header p-2 rounded">
                    <p className="preset-label d-block text-center">Off</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Ligthting;
