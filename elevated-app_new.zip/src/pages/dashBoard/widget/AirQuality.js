import React from "react";

const AirQuality = () => {
  return (
    <>
      <div className="desk__card card__airquality">
        <div className="overallAirQ-block ">
          <div className="airquality-block overallScore">
            <div className="api_fail_AirQ api_fail_wrap displayNone"></div>
            <div
              className="loading_overallScore airquality_loder displayBlock"
              style={{ display: "none" }}
            >
              <div className="flexbox">
                <div>
                  <div className="circle-loader">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="air-quality-block displayNone">
              <div className="custom__select" id="custom__select_dash">
                <select
                  className="custom__hidenSelect"
                  id="custom__hidenSelect_dash"
                >
                  <option
                    value="Awair"
                    data-thumbnail="/images/Awair_Logo_BW.png"
                  >
                    Awair
                  </option>
                  <option
                    value="Airthings"
                    data-thumbnail="/images/Airthings_Logo_BW.png"
                  >
                    Airthings
                  </option>
                </select>
                <button className="btn_select" value="en" id="btn_select_dash">
                  <li className="listItem" value="Awair">
                    <img src="/images/Awair_Logo_BW.png" alt="" />
                    <span>Awair</span>
                  </li>
                </button>
                <div
                  className="dropList__wrap"
                  id="dropList__wrap_dash"
                  style={{ display: "none" }}
                >
                  <ul id="dropList" className="dropList">
                    <li className="listItem" value="Awair">
                      <img src="/images/Awair_Logo_BW.png" alt="" />
                      <span>Awair</span>
                    </li>
                    <li className="listItem" value="Airthings">
                      <img src="/images/Airthings_Logo_BW.png" alt="" />
                      <span>Airthings</span>
                    </li>
                  </ul>
                </div>
              </div>

              <div id="airQualityAPIsRes">
                <div className="temprature-block">
                  <div className="temp-middle-sec">
                    <div
                      data-score="temp"
                      className="temp-list"
                      onclick="getalldeviceScore('score','Awair');"
                    >
                      <div>Indoor Air Quality Score</div>
                      <div id="awairTemperature" style={{ color: "#58FFBF" }}>
                        96.43
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="airquality-block AllSensorBlock" id="allFloorsScore">
            <div className="air-quality-block">
              <div
                className="loading_overallScore_air"
                style={{ display: "none" }}
              >
                <div className="flexbox">
                  <div>
                    <div className="circle-loader">
                      <div></div>
                      <div></div>
                      <div></div>
                      <div></div>
                      <div></div>
                      <div></div>
                      <div></div>
                      <div></div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="air-header">
                <div className="air-q-content">
                  <div className="backtoAverageScore"></div>

                  <div className="customdropdowns">
                    <select id="unitsul">
                      <option value="1">Score</option>
                      <option value="2">Temperature</option>
                      <option value="3">Humidity(%)</option>
                      <option value="4">CO2(ppm)</option>
                      <option value="5">TVOCs(ppd)</option>
                      <option value="6">PM 2.5(ug/m3)</option>
                      <option value="7">Light (lx)</option>
                      <option value="8">Noise (dB)</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="temprature-block inner-scroll-block2 average-scroll">
                <div className="temp-middle-sec" id="unitAvg"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AirQuality;
