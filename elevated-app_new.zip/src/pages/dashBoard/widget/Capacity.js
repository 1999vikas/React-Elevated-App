import React from "react";

const Capacity = () => {
  return (
    <>
      <div className="desk__card card__dansity">
        <div className="floorplan-density-block">
          <div
            className="loading_overallScore density_loder displayBlock 123"
            style={{ display: "none" }}
          >
            <div className="flexbox">
              <div>
                <div className="circle-loader">
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                </div>
              </div>
            </div>
          </div>
          <div className="density-block api_fail_density api_fail_wrap">
            <div className="preview-block">
              <div className="preview-main-block d-flex flex-column">
                <div className="occupancy-teammates-came-office">
                  <span className="occupancy-teammates-came-office-num yellow">
                    0
                  </span>
                  teammates checked in to the office
                </div>
                <div className="occupancy-teammates-images-wrapper">
                  <ul></ul>
                </div>
                <hr className="hr_line m-0" />
                <div className="occupancy-teammates-currently-office">
                  <span>1</span> people currently in the office
                </div>
                <div className="occupancy_teammates_capacity">
                  <p className="text">
                    <span className="text_big">GO</span> 2% of capacity{" "}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Capacity;
