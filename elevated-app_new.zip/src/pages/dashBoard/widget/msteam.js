import React from "react";

const MsTeam = () => {
  return (
    <>
      <div class="desk__card card__people__listing">
        <div
          class="loading_overallScore team_loder displayBlock"
          style={{ display: "none" }}
        >
          <div class="flexbox">
            <div>
              <div class="circle-loader">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
              </div>
            </div>
          </div>
        </div>

        <div class="whoisin-office-block displayNone" id="teamsChatBlock">
          <div id="teamsChatHeader" class="ms_team_card">
            <div class="msCard_profile">
              <div class="PeopleInOfficeBlock">
                <div class="PeopleInOfficeImg">
                  <img
                    class="teamsChatProfileImage people-in-office-dark"
                    src="/fdashboard/images/teams/Widget_People_Picture_Placeholer_Dark.png"
                  />
                </div>
                <div class="inOfficeStatus">
                  <img
                    id="teamsChatPresenceImage"
                    class="teamsPresenceImage"
                    src="/fdashboard/images/teams/presence_unknown.png"
                  />
                </div>
              </div>
              <span id="teamsChatProfileDisplayName" class="name">
                User Name
              </span>
            </div>

            <div class="teamschatProfile-closechat msCard_action">
              <div class="teamschatProfileIcon">
                <img
                  class="people-in-office-dark"
                  src="/fdashboard/images/team_msg.svg"
                />
              </div>
              <img
                onclick="hideTeamsChatBlock()"
                id="teamsChatCloseImage"
                class="people-in-office-dark"
                src="/fdashboard/images/icon_close_line.svg"
              />
            </div>
          </div>

          <div id="teamsChatContainer" class="inner-scroll-block">
            <ul id="teamsMessageBody"> </ul>
          </div>
          <div id="teamsChatBottom">
            <div id="teamsChatBoxContainer">
              <textarea rows="2" id="teamsChatBox"></textarea>
            </div>
            <div id="teamsChatButtonContainer">
              <button id="teamsChatButton" onclick="sendTeamsChatMessage()">
                <img
                  class="people-in-office-dark"
                  src="/fdashboard/images/icon_circle_arrow_line.svg"
                />
              </button>
            </div>
          </div>
        </div>

        <div class="whoisin-office-block" id="teamsUsersBlock">
          <div class="api_fail_wrap api_fail_team" style={{ display: "block" }}>
            <div class="team-down-block down_block_wrap down_block_wrap">
              <h3>
                <span class="text_yellow">Oops! we're having</span>
                <span class="text_yellow">technical trouble</span>
                <span>Looks like we've hit a snag.</span>
                <span>Our tech team is already on it.</span>
              </h3>
            </div>
          </div>

          <div class="people-entered-head">
            <div
              class="inner-scroll-block PeopleInOffice"
              style={{ display: "none" }}
            ></div>
          </div>
        </div>
      </div>
    </>
  );
};

export default MsTeam;
