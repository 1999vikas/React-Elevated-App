import React, { Suspense } from 'react'
import { Dropdown, message, Space } from 'antd';
import { DownOutlined } from '@ant-design/icons';


const index = () => {

    const Weather = React.lazy(() => import("./widget/Weather"));
    const Capacity=React.lazy(()=>import("./widget/Capacity"));
    const AirQuality=React.lazy(()=>import("./widget/AirQuality"));
    const MsTeam=React.lazy(()=>import("./widget/msteam"));
    const Lighting=React.lazy(()=>import("./widget/Ligthting"));


    const onClick = ({ key }) => {
        message.info(`Click on item ${key}`);
    };
    const items = [
        {
            label: '1st menu item',
            key: '1',
        },
        {
            label: '2nd menu item',
            key: '2',
        },
        {
            label: '3rd menu item',
            key: '3',
        },
    ];

    const Icon = () => {
        return "https://staging.elevatedenvironments.tech/fdashboard/images/icon_hamburger.svg";
    }
    return (
        <>
            <section className="section1">
                <div className="organization-head">
                    <span className="big">
                        <form method="POST" action="https://staging.elevatedenvironments.tech/organization_selected" accept-charset="UTF-8" className="form-horizontal" id="selectOrg" enctype="multipart/form-data">
                            <input name="_token" type="hidden" value="GjgUi7QUjaGkUVcIjbagswGZCPa3RInc6r9OmBDC" />
                            <input type="hidden" name="organization_id" id="organization_id_dash" value="" />
                        </form>
                        <div className="custom__select select_2" data-selectwrap="select__wrap">
                            <Dropdown
                                menu={{
                                    items,
                                    onClick,
                                }}
                            >
                                <button onClick={(e) => e.preventDefault()} className="btn_select" value="" data-dropselect="di1">
                                    <li className="listItem" value="undefined">
                                        <span>  <Space>
                                            <DownOutlined />
                                            Richmond

                                        </Space></span>
                                    </li>
                                </button>

                            </Dropdown>
                        </div>


                    </span>



                </div>

                {/* widget Start HERE */}
                <div className="row">

                    {/* Wather widget */}
                    
                    <div style={{ order: 1 }} className="col-sm-6 col-md-6 col-lg-4 col-xl-4 px-small SmDevice">
                    <Suspense fallback={<div>Loading</div>}>
                            <Weather />
                    </Suspense>
                    </div>
                    {/* Wather widget */}

                    {/* AirQuality widget */}
                    <div style={{order:2}} className="col-sm-6 col-md-6 col-lg-4 col-xl-4 px-small SmDevice">
                    <Suspense fallback={<div>Loading</div>}>
                    <AirQuality />
                    </Suspense>
                    </div>
                    {/* AirQuality widget */}

                    {/* Capacity Widget */}
                    <div style={{order:3}} className="col-sm-6 col-md-6 col-lg-4 col-xl-4 px-small SmDevice">
                    <Suspense fallback={<div>Loading</div>}>
                            <Capacity/>
                            </Suspense>
                            </div>
                     {/* Capacity Widget */}
                     <hr style={{order:4}} class="hr_line m-0 d-none d-lg-block"/>
                     {/* MS Team Widget */}
                     <div style={{order:5}} className="col-sm-6 col-md-6 col-lg-4 col-xl-4 px-small SmDevice">
                    <Suspense fallback={<div>Loading</div>}>
                            <MsTeam/>
                            </Suspense>
                            </div>
                     {/* Ms Team Widget */}


                      {/* MS Team Widget */}
                      <div style={{order:6}} className="col-sm-6 col-md-6 col-lg-4 col-xl-4 px-small SmDevice">
                    <Suspense fallback={<div>Loading</div>}>
                            <MsTeam/>
                            </Suspense>
                            </div>
                     {/* Ms Team Widget */}
                        
                        {/* Lighting Widget */}
                        <div style={{order:6}} className="col-sm-6 col-md-6 col-lg-4 col-xl-4 px-small SmDevice">
                    <Suspense fallback={<div>Loading</div>}>
                            <Lighting/>
                            </Suspense>
                            </div>
                        {/* Lighting Widget */}
                </div>
            </section>
        </>
    )
}

export default index