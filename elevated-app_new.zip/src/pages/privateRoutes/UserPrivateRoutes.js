import React from 'react'
import { Navigate, Outlet } from "react-router-dom";

const UserPrivateRoutes = () => {
    return <Outlet />;
}

export default UserPrivateRoutes