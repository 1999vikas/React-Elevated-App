import { Col, Layout } from 'antd'
import React, { useState } from 'react'
import {  Button, Row, Divider } from "antd";
import { useLoginMutation } from '../redux/rkt/features/users/userApi';
const { Content, Footer } = Layout;
const Login = () => {
    const [name,setName]=useState();
    const [password,setPassword]=useState();

    const [login,{isLoading}]=useLoginMutation();
    
    const onClickLogin = () => {
        login({username:name,password});
    }
    return (
        <Layout style={{ background: "#222222" }} className='layout'>
            <Row>
                <Col span={12} offset={6}>
                    <Content style={{
                        padding: "150px 0 180px",
                        maxWidth: "360px",
                        margin: "0 auto",
                        color: 'white'
                    }}>
                        <Divider />

                        <div className="signin-head">
                            <div className="login-align">
                                <div className="login-signup-box">
                                    <h3>Welcome back! Please login to your account.</h3>
                                        <div className="form-group">

                                            <label for="email" className="mb-2">User Email</label>
                                            <input id="email"  className="form-control " name="username" onChange={(e)=>setName(e.currentTarget.value)} value={name} required  type="text" placeholder="Your Email Address" />
                                        </div>
                                        <div className="form-group">


                                            <label for="password" className="mb-2">Password</label>
                                            <input id="password" type="password" className="form-control " value={password} onChange={(e)=>setPassword(e.currentTarget.value)} name="password" required autocomplete="current-password" placeholder="Your Password" />

                                        </div>
                                        <div className="form-group remember-forgot-block">
                                            <div className="custom-checkblock">
                                                <input className="checkbox-custom" type="checkbox" name="remember" id="remember" />
                                                <label for="remember" className="checkbox-custom-label"> Remember Me</label>
                                            </div>
                                            <div className="forgot-password">
                                                <p><a href="https://le.elevatedenvironments.tech/password/reset">Forgot Password?</a></p>

                                            </div>
                                        </div>
                                        <div className="sign-btn-block d-flex justify-content-center">

                                            {/* <button type="submit" className="btn btn-signup">Login</button> */}

                                            <Button type="primary" style={{ background: "#E9EC6B", color: "#2C2E31", height: "45px", width: "160px" }} loading={isLoading} size='large' onClick={onClickLogin}>
                                                Login
                                            </Button>

                                        </div>
                                    
                                </div>
                            </div>
                        </div>

                    </Content>
                </Col>
            </Row>
        </Layout>
    )
}

export default Login