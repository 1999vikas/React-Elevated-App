import React from 'react'
import { Router as RouterHistory ,BrowserRouter,Route,Routes} from "react-router-dom";
import Router from '../router';
import Login from '../pages/Login';
import { ToastContainer } from 'react-toastify';
const App = () => {
  return (
    <>
    <ToastContainer/>
        <Router/>
        </>
  )
}

export default App