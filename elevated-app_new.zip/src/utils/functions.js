import { toast } from "react-toastify";



export function toastHandler(message,status){
    if(status=="warning"){
        toast.warning(message);
    }else if(status=="success"){
        toast.success(message);
    }


}